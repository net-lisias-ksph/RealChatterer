Real Chatterer v0.1 for KSP 1.3.1 and 1.4.5 by TheRealWiwaxia

Real Chatterer is an add-on for the mod Chatterer, that replaces the kerbal gibberish with real recordings of real astronauts, cosmonauts, and even satellites. Real Chatterer is chiefly meant for Realism Overhaul and Real Solar System players to give them a more immersive experience when using Chatterer.

Real Chatterer includes:
81 Apollo clips from Apollo 10, 11, 12, 13, 14, and 15.

31 Apollo EVA clips from Apollo 11, 13, 14 and 15.

26 clips from the Mercury program.

30 Soyuz clips.

9 Vostok and Voskhod clips.

Several new beeps including authentic sounds from Sputnik 1, Sputnik 3, Vanguard, Explorer 1, Explorer 7, Polyot 1, Proton 1, Proton 4, and Cosmos 177.?

AUDIO CREDITS:
Russian Cosmonaut Audio and Satellite noises: Sven's Space Place http://www.svengrahn.pp.se/
Apollo Audio: NASA Audio Archives https://archive.org/details/nasaaudiocollection

LICENSED UNDER: Creative Commons Attribution 4.0 International (CC BY 4.0)

